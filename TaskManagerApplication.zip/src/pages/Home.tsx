import Layout from "../components/dashboard/layout/Layout";

const Home = () => {
  return (
    <>
      <div className=" bg-[#fffbeb] h-screen w-screen">
        <Layout />
      </div>
    </>
  );
};

export default Home;
